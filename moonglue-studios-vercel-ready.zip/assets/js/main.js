/* Moonglue Studios — site script (no dependencies) */
(function () {
  "use strict";

  /* ---- Mobile navigation ---- */
  var toggle = document.querySelector(".nav-toggle");
  var links = document.getElementById("nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", function () {
      var open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && links.classList.contains("open")) {
        links.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  /* ---- Contact form ----
     If the form's action points at a real form service (e.g. Formspree), the
     message is sent with fetch. If the endpoint hasn't been configured yet
     (still contains YOUR_FORM_ID), the form falls back to opening the
     visitor's email app with the message pre-filled, so it always works. */
  var form = document.getElementById("contact-form");
  if (!form) return;

  var status = document.getElementById("form-status");

  function show(msg, ok) {
    status.textContent = msg;
    status.className = "form-status show " + (ok ? "ok" : "err");
    status.focus();
  }

  function validate() {
    var valid = true;
    form.querySelectorAll("[required]").forEach(function (el) {
      var bad = el.type === "checkbox" ? !el.checked : !el.value.trim() || (el.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(el.value.trim()));
      el.setAttribute("aria-invalid", bad ? "true" : "false");
      if (bad) valid = false;
    });
    return valid;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    if (form.querySelector('[name="_gotcha"]').value) return; // spam bot

    if (!validate()) {
      show("Please fill in the required fields with a valid email address.", false);
      var firstBad = form.querySelector('[aria-invalid="true"]');
      if (firstBad) firstBad.focus();
      return;
    }

    var data = new FormData(form);
    var endpoint = form.getAttribute("action") || "";

    if (endpoint.indexOf("YOUR_FORM_ID") !== -1 || endpoint === "") {
      var topic = data.get("topic") || "General enquiry";
      var to = form.getAttribute("data-fallback-email");
      var subject = "[" + topic + "] Message from " + data.get("name");
      var body =
        "Name: " + data.get("name") + "\n" +
        "Email: " + data.get("email") + "\n" +
        "Topic: " + topic + "\n" +
        "Game: " + (data.get("game") || "-") + "\n\n" +
        data.get("message");
      window.location.href = "mailto:" + to + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
      show("Your email app should open with your message ready to send. If it doesn't, email us directly at " + to + ".", true);
      return;
    }

    var btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = "Sending…";

    fetch(endpoint, { method: "POST", body: data, headers: { Accept: "application/json" } })
      .then(function (res) {
        if (!res.ok) throw new Error("Request failed");
        form.reset();
        show("Thanks! Your message has been sent. We'll get back to you as soon as we can.", true);
      })
      .catch(function () {
        show("Sorry, something went wrong sending your message. Please email us directly at " + form.getAttribute("data-fallback-email") + ".", false);
      })
      .finally(function () {
        btn.disabled = false;
        btn.textContent = "Send message";
      });
  });
})();
